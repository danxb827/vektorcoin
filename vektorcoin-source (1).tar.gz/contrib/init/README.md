Sample configuration files for:
```
SystemD: vektorcoind.service
Upstart: vektorcoind.conf
OpenRC:  vektorcoind.openrc
         vektorcoind.openrcconf
CentOS:  vektorcoind.init
macOS:    org.vektorcoin.vektorcoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
